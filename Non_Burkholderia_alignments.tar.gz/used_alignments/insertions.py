#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Feb 26 13:24:28 2018

@author: bram
"""
def collapse_gaps(gapslist):
    if gapslist:
        gaps = []
        gap = (0,0)
        for element in sorted(gapslist):
            if gap == (0,0):
                gap = [element, element]
            else:
                if element-gap[1] == 1:
                    gap[1] = element
                else:
                    gap[1] += 1
                    gaps.append(gap)
                    gap = [element,element]
        gap[1] += 1
        gaps.append(gap)
        return(gaps)
    else:
        return([])

import os
total_gaps = 0
small_gaps = 0
found_motifs_f = 0
found_motifs_r = 0
fw_motifs = []
rv_motifs = []
all_motifs = []
motif_deletions = []
insertion_length = 0

for file in sorted(os.listdir()):
    if file.endswith('.aln'):
        print('===== ' + file + ' =====\n')
        seqdict = {}
        genes = []
        for line in open(file):
            line = line.upper()
            if 'CLUSTAL' not in line and line.strip() and '*' not in line:
                gene, sequence = line.split()
                seqdict[gene] = seqdict.get(gene, '')
                seqdict[gene] += sequence
                if gene not in genes:
                    genes.append(gene)
        pseudo = gene
        gaps = []
        for i in range(len(seqdict[pseudo])):
            outgroup = genes[0]
            ingroup = genes[1]
            pseudo = genes[2]
            if seqdict[outgroup][i] == '-' and seqdict[ingroup][i] == '-' and seqdict[pseudo][i] in ['A', 'G', 'C', 'T']:
                gaps.append(i)
        deletions = collapse_gaps(gaps)
        for deletion in deletions:
            if deletion and deletion[0] != 0 and deletion[1] != len(seqdict[genes[-1]]):
                del_status = 0
                total_gaps += 1
                insertion_length += deletion[1] - deletion[0]
                if deletion[1] - deletion[0] <= 15:
                    small_gaps += 1
                for gene in genes:
                    print(gene[:8], seqdict[gene][max(0, deletion[0]-5):deletion[1]+5])
                print()
                print('-'*50+'\n')

print('Insertions: ', total_gaps)
print('Insertions <= 15:', small_gaps)
print('Total Insertion Length:', insertion_length)
